class CrawlerConfig {}
