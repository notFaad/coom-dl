import 'dart:async';

import 'package:coom_dl/data/models/DlTask.dart';
import 'package:coom_dl/data/models/Link.dart';
import 'package:coom_dl/downloader/coomercrawl.dart';
import 'package:get/get.dart';
import 'package:isar/isar.dart';

class DownloadTaskServices {
  DownloadTask task;

  DownloadTaskServices({required this.task});

  Future<void> startDownload(
    Isar isar,
    StreamSink singleComplete,
    int type,
  ) async {
    await CybCrawl.getFileContent(
      downloadID: task.id,
      url: task.url,
      isar: isar,
      onError: () {
        isar.writeTxn(() async {
          DownloadTask? temp =
              await isar.downloadTasks.where().idEqualTo(task.id).findFirst();
          if (temp != null) {
            temp.isFailed = true;
            temp.isCanceled = false;
            temp.isDownloading = false;
            temp.isPaused = false;
            temp.isCompleted = false;
            await isar.downloadTasks.put(temp);
          }
        });
      },
      onComplete: () async {
        await isar.writeTxn(() async {
          DownloadTask? temp =
              await isar.downloadTasks.where().idEqualTo(task.id).findFirst();
          if (temp != null) {
            temp.isCompleted = true;
            temp.isDownloading = false;
            await isar.downloadTasks.put(temp);
          }
        });

        //send to stream
        singleComplete.add({"": ""});
      },
      download_type: type,
      onDownloadedAlbum: (value) async {
        await isar.writeTxn(() async {
          DownloadTask? temp =
              await isar.downloadTasks.where().idEqualTo(task.id).findFirst();
          if (temp != null) {
            temp.numFetched = value;
            await isar.downloadTasks.put(temp);
          }
        });
      },
      totalAlbums: (value) async {
        await isar.writeTxn(() async {
          DownloadTask? temp =
              await isar.downloadTasks.where().idEqualTo(task.id).findFirst();
          if (temp != null) {
            temp.totalNum = value[0];
            temp.name = value[1];
            await isar.downloadTasks.put(temp);
          }
        });
      },
      onThreadchange: (value) {},
      direct: task.storagePath,
      log: (val) async {
        DownloadTask? temp =
            await isar.downloadTasks.where().idEqualTo(task.id).findFirst();

        if (temp != null) {
          if (val['status'] == "ok") {
            temp.numCompleted += 1;
            temp.links
                .firstWhere((element) => element.id.isEqual(val['id']))
                .isCompleted = true;
          } else if (val['status'] == "fail") {
            temp.numFailed += 1;

            temp.links
                .firstWhere((element) => element.id.isEqual(val['id']))
                .isFailure = true;
          }

          await isar.writeTxn(() async {
            await isar.downloadTasks.put(temp);
            await temp.links.save();
          });
        }
      },
      jobs: 4,
      retry: 6,
    ).onError((error, stackTrace) {
      return Future.error(error.toString());
    });
  }
}
