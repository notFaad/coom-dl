import 'dart:io';

import 'package:coom_dl/data/models/DlTask.dart';
import 'package:coom_dl/utils/FileSizeConverter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:isar/isar.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constant/appcolors.dart';

class DownloadWidget extends StatefulWidget {
  DownloadTask task;
  Isar isar;
  DownloadWidget({Key? key, required this.task, required this.isar})
      : super(key: key);

  @override
  _DownloadWidgetState createState() => _DownloadWidgetState();
}

class _DownloadWidgetState extends State<DownloadWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      child: Container(
        decoration: BoxDecoration(
            color: Appcolors.appNaigationColor.withAlpha(80),
            boxShadow: [
              BoxShadow(
                  color: Appcolors.appAccentColor.withAlpha(80),
                  blurRadius: 0,
                  blurStyle: BlurStyle.outer,
                  offset: const Offset(2, 2),
                  spreadRadius: 0.5)
            ],
            borderRadius: BorderRadius.circular(5)),
        height: 100,
        child: Row(
          children: [
            // image
            Column(
              children: [
                Container(
                    margin: const EdgeInsets.all(5),
                    padding: const EdgeInsets.all(5),
                    width: 90,
                    height: 90,
                    color: Appcolors.appBackgroundColor.withAlpha(80),
                    child: () {
                      if (widget.task.pathToThumbnail == null) {
                        return Image.asset(
                          'assets/Cnex.png',
                          fit: BoxFit.fitWidth,
                        );
                      } else {
                        return Image.file(
                          File(
                              "/Users/saadal-ageel/coom-dl/coomdl/assets/logo.png"),
                          fit: BoxFit.cover,
                        );
                      }
                    }()),
              ],
            ),
            // Download information
            Expanded(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: SizedBox(
                          width: 200,
                          child: Text(
                            overflow: TextOverflow.ellipsis,
                            "${widget.task.name ?? "No Name"}",
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Appcolors.appPrimaryColor,
                                fontSize: 21),
                          )),
                    ),
                    SizedBox(
                        width: 90,
                        height: 25,
                        child: Container(
                            color: Appcolors.appBackgroundColor.withAlpha(50),
                            child: Center(
                                child: Text(
                                    "${widget.task.tag ?? "No Tag"}", // <- Site match here
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Appcolors.appPrimaryColor,
                                        fontSize: 9))))),
                    const Spacer(),
                    if (widget.task.totalNum != null) ...[
                      Container(
                        margin: const EdgeInsets.all(8),
                        padding: const EdgeInsets.all(5),
                        color: Appcolors.appBackgroundColor.withAlpha(50),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                                style: IconButton.styleFrom(
                                    hoverColor: Appcolors.appPrimaryColor,
                                    foregroundColor: Appcolors.appAccentColor,
                                    backgroundColor:
                                        Appcolors.appNaigationColor),
                                onPressed: () async {
                                  // Pause Download Button
                                  await widget.isar.writeTxn(() async {
                                    DownloadTask? temp = await widget
                                        .isar.downloadTasks
                                        .where()
                                        .idEqualTo(widget.task.id)
                                        .findFirst();
                                    if (temp != null) {
                                      temp.isPaused = !temp.isPaused!;

                                      await widget.isar.downloadTasks.put(temp);
                                    }
                                  });
                                },
                                icon: const Icon(
                                  Icons.pause,
                                  size: 16,
                                )),
                            const SizedBox(
                              width: 10,
                            ),
                            IconButton(
                                style: IconButton.styleFrom(
                                    hoverColor: Appcolors.appPrimaryColor,
                                    foregroundColor: Appcolors.appAccentColor,
                                    backgroundColor:
                                        Appcolors.appNaigationColor),
                                onPressed: () {
                                  // Open Download Directory
                                  Uri _url = Uri.parse(
                                      'file://${widget.task.storagePath}/${widget.task.name}/');
                                  launchUrl(_url);
                                },
                                icon: const Icon(
                                  Icons.folder_rounded,
                                  size: 16,
                                )),
                            const SizedBox(
                              width: 10,
                            ),
                            IconButton(
                                style: IconButton.styleFrom(
                                    hoverColor: Colors.red[400],
                                    foregroundColor: Appcolors.appAccentColor,
                                    backgroundColor:
                                        Appcolors.appNaigationColor),
                                onPressed: () async {
                                  // Stop and Delete download
                                  var tmp = await widget.isar.downloadTasks
                                      .where()
                                      .idEqualTo(widget.task.id)
                                      .findFirst();
                                  tmp!.isCanceled = true;
                                  await widget.isar.writeTxn(() async {
                                    await widget.isar.downloadTasks.put(tmp);
                                  });
                                },
                                icon: const Icon(
                                  Icons.delete_forever,
                                  size: 16,
                                )),
                          ],
                        ),
                      )
                    ]
                  ],
                ),

                const Spacer(),
                // Download information
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 1),
                      child: () {
                        if (widget.task.totalNum == null) {
                          return const Text(
                            overflow: TextOverflow.ellipsis,
                            "Contacting Crawler...",
                            style: TextStyle(
                                color: Appcolors.appPrimaryColor, fontSize: 11),
                          )
                              .animate(
                            onPlay: (controller) =>
                                controller.repeat(reverse: false),
                          )
                              .shimmer(
                                  duration: const Duration(
                                      seconds: 1, milliseconds: 200),
                                  colors: [
                                Appcolors.appLogoColor,
                                Appcolors.appPrimaryColor
                              ]);
                        } else {
                          return Text(
                            overflow: TextOverflow.ellipsis,
                            "[ ${widget.task.numFetched} / ${widget.task.totalNum} ] | D: ${widget.task.numCompleted} | F: ${widget.task.numFailed} | ${((widget.task.numFetched / widget.task.totalNum!) * 100).toStringAsFixed(1)} % | ${FileSizeConverter.getFileSizeString(bytes: widget.task.downloadedBytes)}",
                            style: TextStyle(
                                color: Appcolors.appPrimaryColor,
                                fontSize: 12,
                                fontWeight: FontWeight.w500),
                          )
                              .animate(
                            onPlay: (controller) =>
                                controller.repeat(reverse: false),
                          )
                              .shimmer(
                                  duration: const Duration(
                                      seconds: 4, milliseconds: 0),
                                  colors: [
                                Appcolors.appTextColor,
                                Appcolors.appLogoColor
                              ]);
                          ;
                        }
                      }(),
                    )
                  ],
                ),
                if (widget.task.totalNum != null) ...[
                  SizedBox(
                      height: 7.5,
                      width: double.infinity,
                      child: LinearProgressIndicator(
                        value:
                            (widget.task.numFetched! / widget.task.totalNum!),
                        backgroundColor: Appcolors.appLogoColor,
                        color: Appcolors.appPrimaryColor,
                      ))
                ]
              ],
            ))
          ],
        ),
      ),
    );
  }
}
